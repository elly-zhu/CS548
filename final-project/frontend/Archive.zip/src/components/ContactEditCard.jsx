import React from "react";

const ContactEditCard = () => {
  return <div>ContactEditCard</div>;
};

export default ContactEditCard;
